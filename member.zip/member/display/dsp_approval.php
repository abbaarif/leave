<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">Waiting for Approval</h1>
	</div>
</div>
<div class="row">
	<!-- /.panel-heading -->
	<div class="panel-body">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-hover">
				<thead>
					<tr>
						<th class="centered" rowspan="2">No</th>
						<th class="centered" rowspan="2">Tgl dibuat</th>
						<th class="centered" rowspan="2">Jml hari</th>
						<th class="centered" rowspan="2">Mulai</th>
						<th class="centered" rowspan="2">Selesai</th>
						<th class="centered" rowspan="2">Keperluan</th>
						<th class="centered" colspan="3">Respon atasan</th>
						<th class="centered" colspan="3">Respon HRD</th>
					</tr>
					<tr>
						<th class="centered">Tgl</td>
						<th class="centered">Status</th>
						<th class="centered">Alasan</th>
						<th class="centered">Tgl</td>
						<th class="centered">Status</th>
						<th class="centered">Alasan</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>1</td>
						<td>2016-01-04</td>
						<td>2</td>
						<td>2016-01-05</td>
						<td>2016-01-06</td>
						<td>--</td>
						<td>2016-01-04</td>
						<td class="approved">Approved</td>
						<td>-</td>
						<td>2016-01-04</td>
						<td class="approved">Approved</td>
						<td>-</td>
					</tr>
					
					<tr>
						<td>2</td>
						<td>2016-01-04</td>
						<td>2</td>
						<td>2016-01-05</td>
						<td>2016-01-06</td>
						<td>--</td>
						<td>2016-01-04</td>
						<td class="rejected">Rejected</td>
						<td>-</td>
						<td>2016-01-04</td>
						<td class="rejected">Rejected</td>
						<td>-</td>
					</tr>
				</tbody>
			</table>
		</div>
		<!-- /.table-responsive -->
	</div>
	<!-- /.panel-body -->
</div>